function togglesidebar(){
  document.getElementById('sidebar').classList.toggle('active');
}
    